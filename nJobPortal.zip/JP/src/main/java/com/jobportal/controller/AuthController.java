package com.jobportal.controller;

import com.jobportal.dto.RegisterDto;
import com.jobportal.service.EmailService;
import com.jobportal.service.OtpService;
import com.jobportal.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequiredArgsConstructor
public class AuthController {

    private final UserService  userService;
    private final OtpService   otpService;
    private final EmailService emailService;

    private static final String SESSION_KEY = "pendingRegistration";

    @GetMapping("/login")
    public String loginPage(@RequestParam(value = "error", required = false) String error,
                            @RequestParam(value = "logout", required = false) String logout,
                            Model model) {
        if (error != null) {
            model.addAttribute("loginError", "Invalid username or password.");
        }
        if (logout != null) {
            model.addAttribute("logoutMsg", "You have been logged out.");
        }
        return "auth/login";
    }

    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("registerDto", new RegisterDto());
        return "auth/register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("registerDto") RegisterDto dto,
                           BindingResult result,
                           HttpSession session,
                           RedirectAttributes redirectAttributes,
                           Model model) {
        if (result.hasErrors()) {
            return "auth/register";
        }
        if (userService.usernameExists(dto.getUsername())) {
            model.addAttribute("usernameError", "Username is already taken.");
            return "auth/register";
        }
        if (userService.emailExists(dto.getEmail())) {
            model.addAttribute("emailError", "Email is already registered.");
            return "auth/register";
        }

        // Store registration data in session (not saved to DB yet)
        session.setAttribute(SESSION_KEY, dto);

        // Generate OTP and send it
        String otp = otpService.generateOtp(dto.getEmail());
        emailService.sendOtpEmail(dto.getEmail(), dto.getName(), otp);

        redirectAttributes.addFlashAttribute("otpSent",
                "A verification code has been sent to your email.");
        return "redirect:/verify-otp";
    }
}
