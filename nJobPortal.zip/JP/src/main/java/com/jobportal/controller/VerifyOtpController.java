package com.jobportal.controller;

import com.jobportal.dto.RegisterDto;
import com.jobportal.service.EmailService;
import com.jobportal.service.OtpService;
import com.jobportal.service.UserService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Handles the OTP verification step that sits between registration and DB save.
 * The pending RegisterDto is held in the HTTP session under "pendingRegistration"
 * so no sensitive data is stored server-side beyond the session lifetime.
 */
@Controller
@RequiredArgsConstructor
public class VerifyOtpController {

    private final OtpService    otpService;
    private final EmailService  emailService;
    private final UserService   userService;

    private static final String SESSION_KEY = "pendingRegistration";

    // ── GET /verify-otp ───────────────────────────────────────────────────────

    @GetMapping("/verify-otp")
    public String verifyOtpPage(HttpSession session, Model model) {
        RegisterDto pending = (RegisterDto) session.getAttribute(SESSION_KEY);
        if (pending == null) {
            // No pending registration → back to register
            return "redirect:/register";
        }
        // Mask the email for display: show only first 3 chars + domain
        String masked = maskEmail(pending.getEmail());
        model.addAttribute("maskedEmail", masked);
        return "auth/verify-otp";
    }

    // ── POST /verify-otp ──────────────────────────────────────────────────────

    @PostMapping("/verify-otp")
    public String verifyOtp(@RequestParam("otp") String otp,
                            HttpSession session,
                            RedirectAttributes redirectAttributes,
                            Model model) {

        RegisterDto pending = (RegisterDto) session.getAttribute(SESSION_KEY);
        if (pending == null) {
            return "redirect:/register";
        }

        if (!otpService.validateOtp(pending.getEmail(), otp.trim())) {
            String masked = maskEmail(pending.getEmail());
            model.addAttribute("maskedEmail", masked);
            model.addAttribute("otpError", "Invalid or expired OTP. Please try again.");
            return "auth/verify-otp";
        }

        // OTP is valid → save user to DB
        userService.register(pending);

        // Send welcome email (async – does not block redirect)
        emailService.sendWelcomeEmail(pending.getEmail(), pending.getName(), pending.getRole());

        // Clear session
        session.removeAttribute(SESSION_KEY);

        redirectAttributes.addFlashAttribute("success",
                "Email verified! Your account has been created. Please log in.");
        return "redirect:/login";
    }

    // ── POST /verify-otp/resend ───────────────────────────────────────────────

    @PostMapping("/verify-otp/resend")
    public String resendOtp(HttpSession session,
                            RedirectAttributes redirectAttributes) {

        RegisterDto pending = (RegisterDto) session.getAttribute(SESSION_KEY);
        if (pending == null) {
            return "redirect:/register";
        }

        otpService.invalidate(pending.getEmail());
        String newOtp = otpService.generateOtp(pending.getEmail());
        emailService.sendOtpEmail(pending.getEmail(), pending.getName(), newOtp);

        redirectAttributes.addFlashAttribute("resendSuccess",
                "A new OTP has been sent to your email.");
        return "redirect:/verify-otp";
    }

    // ── Helper ────────────────────────────────────────────────────────────────

    private String maskEmail(String email) {
        if (email == null || !email.contains("@")) return email;
        String[] parts = email.split("@");
        String local  = parts[0];
        String domain = parts[1];
        String visible = local.length() > 3 ? local.substring(0, 3) : local;
        return visible + "***@" + domain;
    }
}
