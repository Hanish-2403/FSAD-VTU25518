package com.jobportal.service;

import com.jobportal.model.Application;
import com.jobportal.model.Job;
import com.jobportal.model.User;
import com.jobportal.repository.ApplicationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final EmailService emailService;

    public List<Application> getApplicationsByStudent(User student) {
        return applicationRepository.findByStudentOrderByAppliedAtDesc(student);
    }

    public List<Application> getApplicationsByJob(Job job) {
        return applicationRepository.findByJobOrderByAppliedAtDesc(job);
    }

    public boolean hasApplied(User student, Job job) {
        return applicationRepository.existsByStudentAndJob(student, job);
    }

    @Transactional
    public Application apply(User student, Job job) {
        if (hasApplied(student, job)) {
            throw new RuntimeException("You have already applied for this job");
        }
        Application application = new Application();
        application.setStudent(student);
        application.setJob(job);
        application.setStatus(Application.Status.APPLIED);
        Application saved = applicationRepository.save(application);

        // Send confirmation email (async – never blocks the HTTP response)
        String companyName = (job.getEmployer() != null && job.getEmployer().getCompany() != null)
                ? job.getEmployer().getCompany()
                : "the employer";
        emailService.sendApplicationConfirmationEmail(
                student.getEmail(),
                student.getName(),
                job.getTitle(),
                companyName);

        return saved;
    }

    @Transactional
    public void updateStatus(Long applicationId, Application.Status newStatus, User employer) {
        Application app = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found"));
        if (!app.getJob().getEmployer().getId().equals(employer.getId())) {
            throw new RuntimeException("Not authorized to update this application");
        }
        app.setStatus(newStatus);
        applicationRepository.save(app);
    }

    public long countApplicationsByEmployer(User employer) {
        return applicationRepository.countApplicationsByEmployer(employer);
    }

    public List<Application> getApplicationsByEmployerAndStatus(User employer, Application.Status status) {
        return applicationRepository.findByEmployerAndStatus(employer, status);
    }
}
