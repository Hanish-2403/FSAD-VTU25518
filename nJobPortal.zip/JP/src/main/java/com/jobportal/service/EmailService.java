package com.jobportal.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * Sends transactional HTML emails via Gmail SMTP.
 * All methods are @Async so the HTTP request is never blocked by mail delivery.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender mailSender;

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Sends a 6-digit OTP email to the registering user.
     */
    @Async
    public void sendOtpEmail(String toEmail, String recipientName, String otp) {
        String subject = "Your Job Portal Verification Code";
        String body = """
                <!DOCTYPE html>
                <html>
                <body style="margin:0;padding:0;background:#f3f4f6;font-family:Arial,sans-serif;">
                  <table width="100%%" cellpadding="0" cellspacing="0">
                    <tr><td align="center" style="padding:40px 0;">
                      <table width="520" cellpadding="0" cellspacing="0"
                             style="background:#ffffff;border-radius:12px;overflow:hidden;
                                    box-shadow:0 4px 24px rgba(0,0,0,.08);">
                        <!-- Header -->
                        <tr>
                          <td style="background:linear-gradient(135deg,#1d4ed8,#3b82f6);
                                     padding:32px 40px;text-align:center;">
                            <h1 style="margin:0;color:#ffffff;font-size:26px;letter-spacing:.5px;">
                              Job Portal
                            </h1>
                            <p style="margin:6px 0 0;color:#bfdbfe;font-size:14px;">
                              Email Verification
                            </p>
                          </td>
                        </tr>
                        <!-- Body -->
                        <tr>
                          <td style="padding:40px 40px 32px;">
                            <p style="margin:0 0 8px;color:#111827;font-size:16px;">
                              Hi <strong>%s</strong>,
                            </p>
                            <p style="margin:0 0 28px;color:#6b7280;font-size:14px;line-height:1.6;">
                              Thank you for registering! Use the code below to verify your email address.
                              This code is valid for <strong>5 minutes</strong>.
                            </p>
                            <!-- OTP Box -->
                            <div style="background:#eff6ff;border:2px dashed #3b82f6;
                                        border-radius:10px;text-align:center;padding:24px;">
                              <p style="margin:0;font-size:40px;font-weight:700;
                                        letter-spacing:12px;color:#1d4ed8;">%s</p>
                            </div>
                            <p style="margin:24px 0 0;color:#6b7280;font-size:12px;line-height:1.6;">
                              If you did not request this, you can safely ignore this email.
                            </p>
                          </td>
                        </tr>
                        <!-- Footer -->
                        <tr>
                          <td style="background:#f9fafb;padding:20px 40px;text-align:center;
                                     border-top:1px solid #e5e7eb;">
                            <p style="margin:0;color:#9ca3af;font-size:12px;">
                              © 2025 Job Portal. All rights reserved.
                            </p>
                          </td>
                        </tr>
                      </table>
                    </td></tr>
                  </table>
                </body>
                </html>
                """.formatted(recipientName, otp);
        send(toEmail, subject, body);
    }

    /**
     * Sends a welcome email after successful OTP verification and account creation.
     */
    @Async
    public void sendWelcomeEmail(String toEmail, String recipientName, String role) {
        String roleLabel = "EMPLOYER".equalsIgnoreCase(role) ? "Employer" : "Student / Job Seeker";
        String subject   = "Welcome to Job Portal, " + recipientName + "!";
        String body = """
                <!DOCTYPE html>
                <html>
                <body style="margin:0;padding:0;background:#f3f4f6;font-family:Arial,sans-serif;">
                  <table width="100%%" cellpadding="0" cellspacing="0">
                    <tr><td align="center" style="padding:40px 0;">
                      <table width="520" cellpadding="0" cellspacing="0"
                             style="background:#ffffff;border-radius:12px;overflow:hidden;
                                    box-shadow:0 4px 24px rgba(0,0,0,.08);">
                        <!-- Header -->
                        <tr>
                          <td style="background:linear-gradient(135deg,#1d4ed8,#3b82f6);
                                     padding:32px 40px;text-align:center;">
                            <h1 style="margin:0;color:#ffffff;font-size:26px;letter-spacing:.5px;">
                              Welcome aboard! 🎉
                            </h1>
                          </td>
                        </tr>
                        <!-- Body -->
                        <tr>
                          <td style="padding:40px 40px 32px;">
                            <p style="margin:0 0 16px;color:#111827;font-size:16px;">
                              Hi <strong>%s</strong>,
                            </p>
                            <p style="margin:0 0 16px;color:#374151;font-size:14px;line-height:1.7;">
                              Your account has been verified and created successfully.
                              You are registered as a <strong>%s</strong> on Job Portal.
                            </p>
                            <p style="margin:0 0 28px;color:#374151;font-size:14px;line-height:1.7;">
                              You can now log in and start exploring opportunities.
                            </p>
                            <div style="text-align:center;margin:0 0 24px;">
                              <a href="http://localhost:8081/login"
                                 style="display:inline-block;background:#1d4ed8;color:#ffffff;
                                        text-decoration:none;padding:14px 36px;border-radius:8px;
                                        font-size:15px;font-weight:600;">
                                Go to Login
                              </a>
                            </div>
                            <p style="margin:0;color:#6b7280;font-size:12px;line-height:1.6;">
                              If you did not create this account, please contact support immediately.
                            </p>
                          </td>
                        </tr>
                        <!-- Footer -->
                        <tr>
                          <td style="background:#f9fafb;padding:20px 40px;text-align:center;
                                     border-top:1px solid #e5e7eb;">
                            <p style="margin:0;color:#9ca3af;font-size:12px;">
                              © 2025 Job Portal. All rights reserved.
                            </p>
                          </td>
                        </tr>
                      </table>
                    </td></tr>
                  </table>
                </body>
                </html>
                """.formatted(recipientName, roleLabel);
        send(toEmail, subject, body);
    }

    /**
     * Sends a job application confirmation email to the student.
     */
    @Async
    public void sendApplicationConfirmationEmail(String toEmail, String studentName,
                                                 String jobTitle, String companyName) {
        String subject = "Application Submitted – " + jobTitle;
        String body = """
                <!DOCTYPE html>
                <html>
                <body style="margin:0;padding:0;background:#f3f4f6;font-family:Arial,sans-serif;">
                  <table width="100%%" cellpadding="0" cellspacing="0">
                    <tr><td align="center" style="padding:40px 0;">
                      <table width="520" cellpadding="0" cellspacing="0"
                             style="background:#ffffff;border-radius:12px;overflow:hidden;
                                    box-shadow:0 4px 24px rgba(0,0,0,.08);">
                        <!-- Header -->
                        <tr>
                          <td style="background:linear-gradient(135deg,#059669,#10b981);
                                     padding:32px 40px;text-align:center;">
                            <h1 style="margin:0;color:#ffffff;font-size:22px;letter-spacing:.5px;">
                              Application Submitted ✅
                            </h1>
                          </td>
                        </tr>
                        <!-- Body -->
                        <tr>
                          <td style="padding:40px 40px 32px;">
                            <p style="margin:0 0 16px;color:#111827;font-size:16px;">
                              Hi <strong>%s</strong>,
                            </p>
                            <p style="margin:0 0 24px;color:#374151;font-size:14px;line-height:1.7;">
                              Your application has been successfully submitted. Here are the details:
                            </p>
                            <!-- Detail Card -->
                            <table width="100%%" cellpadding="0" cellspacing="0"
                                   style="background:#f0fdf4;border:1px solid #bbf7d0;
                                          border-radius:10px;margin-bottom:24px;">
                              <tr>
                                <td style="padding:20px 24px;">
                                  <p style="margin:0 0 10px;font-size:13px;color:#6b7280;">
                                    POSITION
                                  </p>
                                  <p style="margin:0 0 16px;font-size:18px;font-weight:700;
                                            color:#065f46;">%s</p>
                                  <p style="margin:0 0 6px;font-size:13px;color:#6b7280;">
                                    COMPANY
                                  </p>
                                  <p style="margin:0;font-size:15px;font-weight:600;color:#111827;">
                                    %s
                                  </p>
                                </td>
                              </tr>
                            </table>
                            <p style="margin:0;color:#374151;font-size:14px;line-height:1.7;">
                              You can track the status of your application in your
                              <a href="http://localhost:8081/student/applications"
                                 style="color:#1d4ed8;text-decoration:none;font-weight:600;">
                                My Applications
                              </a>
                              dashboard. Good luck! 🚀
                            </p>
                          </td>
                        </tr>
                        <!-- Footer -->
                        <tr>
                          <td style="background:#f9fafb;padding:20px 40px;text-align:center;
                                     border-top:1px solid #e5e7eb;">
                            <p style="margin:0;color:#9ca3af;font-size:12px;">
                              © 2025 Job Portal. All rights reserved.
                            </p>
                          </td>
                        </tr>
                      </table>
                    </td></tr>
                  </table>
                </body>
                </html>
                """.formatted(studentName, jobTitle, companyName);
        send(toEmail, subject, body);
    }

    // ── Private helper ────────────────────────────────────────────────────────

    private void send(String to, String subject, String htmlBody) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(htmlBody, true); // true = HTML
            mailSender.send(message);
            log.info("Email sent to {}: {}", to, subject);
        } catch (MessagingException e) {
            log.error("Failed to send email to {}: {}", to, e.getMessage(), e);
        }
    }
}
