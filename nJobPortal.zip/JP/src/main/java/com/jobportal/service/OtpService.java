package com.jobportal.service;

import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Simple in-memory OTP service.
 * Stores OTPs keyed by email with a 5-minute expiry window.
 * No Redis / external store required.
 */
@Service
public class OtpService {

    private static final long OTP_TTL_SECONDS = 300; // 5 minutes
    private static final SecureRandom RANDOM = new SecureRandom();

    /** email → { otp, expiryEpochSecond } */
    private final Map<String, OtpEntry> store = new ConcurrentHashMap<>();

    // ── Public API ────────────────────────────────────────────────────────────

    /** Generate, store and return a fresh 6-digit OTP for the given email. */
    public String generateOtp(String email) {
        String otp = String.format("%06d", RANDOM.nextInt(1_000_000));
        store.put(email.toLowerCase(), new OtpEntry(otp, Instant.now().getEpochSecond() + OTP_TTL_SECONDS));
        return otp;
    }

    /**
     * Validate the OTP for the given email.
     * Returns true only if the OTP matches and has not expired.
     * On success, the entry is removed so it cannot be reused.
     */
    public boolean validateOtp(String email, String otp) {
        OtpEntry entry = store.get(email.toLowerCase());
        if (entry == null) return false;
        if (Instant.now().getEpochSecond() > entry.expiryEpoch()) {
            store.remove(email.toLowerCase());
            return false;
        }
        if (!entry.otp().equals(otp)) return false;
        store.remove(email.toLowerCase()); // single-use
        return true;
    }

    /** Remove any stored OTP for the given email (e.g. on re-send). */
    public void invalidate(String email) {
        store.remove(email.toLowerCase());
    }

    // ── Internal record ───────────────────────────────────────────────────────

    private record OtpEntry(String otp, long expiryEpoch) {}
}
